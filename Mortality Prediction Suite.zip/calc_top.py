import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
import csv
import os
from datetime import datetime

# ------------------- Logistic Model -------------------
class LogisticModel:
    def __init__(self, coefficients):
        self.coefficients = coefficients

    def predict_mortality_probability(self, input_variables):
        input_with_intercept = np.array([1] + input_variables)
        linear_combination = np.dot(self.coefficients, input_with_intercept)
        probability = 1 / (1 + np.exp(-linear_combination))
        return probability

# ------------------- Model Data -------------------
model_coefficients = {
    1: [-8.562, 3.142],
    2: [-9.835, 3.227, 0.006],
    3: [-11.115, 3.208, 0.01, 1.347],
    4: [-11.8, 3.376, 0.01, 1.374, 1.075],
    5: [-12.822, 3.33, 0.009, 1.821, 1.18, 0.002],
    6: [-15.248, 3.107, 0.009, 0.002, 2.39, 0.047, 0.815],
    7: [-15.749, 3.377, 0.009, 1.83, 1.433, 0.002, -0.046, 0.008],
    8: [-15.984, 3.303, 0.009, 1.902, 1.424, 0.002, -0.045, 0.008, 0.233],
    9: [-14.981, 2.96, 0.009, 0.055, -0.048, 0.002, 2.701, -0.003, 0.223, 0.086],
    10: [-15.784, 2.952, 0.009, 0.058, -0.046, 0.002, 2.729, -0.003, 0.212, 0.08, 0.021]
}

model_variable_names = {
    1: ["Ventilatory Ratio (VR)"],
    2: ["Ventilatory Ratio (VR)", "Glucose"],
    3: ["Ventilatory Ratio (VR)", "Glucose", "COVID status"],
    4: ["Ventilatory Ratio (VR)", "Glucose", "COVID status", "Hypertension (HAS)"],
    5: ["Ventilatory Ratio (VR)", "Glucose", "COVID status", "Hypertension (HAS)", "DHL"],
    6: ["Ventilatory Ratio (VR)", "Glucose", "DHL", "COVID status", "Age", "Vasopressor"],
    7: ["Ventilatory Ratio (VR)", "Glucose", "COVID status", "Hypertension (HAS)", "DHL", "Time", "Tidal Volume (VT)"],
    8: ["Ventilatory Ratio (VR)", "Glucose", "COVID status", "Hypertension (HAS)", "DHL", "Time", "Tidal Volume (VT)", "Creatinine"],
    9: ["Ventilatory Ratio (VR)", "Glucose", "Age", "Time", "DHL", "COVID status", "Platelets", "Creatinine", "PEEP"],
    10: ["Ventilatory Ratio (VR)", "Glucose", "Age", "Time", "DHL", "COVID status", "Platelets", "Creatinine", "PEEP", "BMI"]
}

# ------------------- Logic -------------------
def calculate_mortality(model_number, input_variables):
    coefficients = model_coefficients[model_number]
    model = LogisticModel(coefficients)
    return model.predict_mortality_probability(input_variables)

def save_to_csv(patient_id, patient_name, model_number, input_values, variable_names, probability):
    filename = "mortality_results.csv"
    file_exists = os.path.isfile(filename)

    with open(filename, mode="a", newline='') as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow([
                "Timestamp", "Patient ID", "Patient Name", "Model", "Variables (Name=Value)", "Mortality Probability"
            ])
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        variables_str = "; ".join([
            f"{name}={val:.4f}" for name, val in zip(variable_names, input_values)
        ])
        writer.writerow([
            timestamp, patient_id, patient_name, model_number, variables_str, f"{probability:.4f}"
        ])

def on_calculate():
    try:
        patient_id = patient_id_entry.get().strip()
        patient_name = patient_name_entry.get().strip()
        model_number = int(model_dropdown.get())

        input_values = [float(entry.get()) for entry in input_entries]
        variable_names = model_variable_names[model_number]
        probability = calculate_mortality(model_number, input_values)

        save_to_csv(patient_id, patient_name, model_number, input_values, variable_names, probability)

        messagebox.showinfo(
            "Mortality Probability",
            f"Patient ID: {patient_id}\nName: {patient_name}\n\nMortality Probability: {probability:.4f}\n\nResult saved to CSV."
        )

    except Exception as e:
        messagebox.showerror("Error", str(e))

def update_input_fields(event=None):
    model_number = int(model_dropdown.get())

    for widget in variable_frame.winfo_children():
        widget.destroy()

    input_labels.clear()
    input_entries.clear()

    variable_names = model_variable_names[model_number]
    for i, var_name in enumerate(variable_names):
        lbl = ttk.Label(variable_frame, text=f"{var_name}:", font=('Segoe UI', 10))
        lbl.grid(row=i, column=0, padx=5, pady=5, sticky="e")
        ent = ttk.Entry(variable_frame)
        ent.grid(row=i, column=1, padx=5, pady=5)
        input_labels.append(lbl)
        input_entries.append(ent)

# ------------------- GUI Layout -------------------
root = tk.Tk()
root.title("Mortality Risk Prediction Tool")
root.geometry("550x650")
root.configure(bg="#f2f2f2")
root.resizable(False, False)

style = ttk.Style()
style.theme_use("default")

style.configure("TLabel", font=("Segoe UI", 10))
style.configure("TEntry", font=("Segoe UI", 10))
style.configure("TCombobox", padding=4)

# 🎨 Blue Button Style
style.configure("Blue.TButton",
                background="#007acc",
                foreground="white",
                font=("Segoe UI", 10, "bold"),
                padding=6)
style.map("Blue.TButton",
          background=[("active", "#005f99")],
          foreground=[("active", "white")])

# -- Patient Info Frame --
patient_frame = ttk.LabelFrame(root, text="Patient Information", padding=(10, 10))
patient_frame.pack(padx=10, pady=10, fill="x")

ttk.Label(patient_frame, text="Patient ID:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
patient_id_entry = ttk.Entry(patient_frame)
patient_id_entry.grid(row=0, column=1, padx=5, pady=5)

ttk.Label(patient_frame, text="Patient Name:").grid(row=1, column=0, padx=5, pady=5, sticky="e")
patient_name_entry = ttk.Entry(patient_frame)
patient_name_entry.grid(row=1, column=1, padx=5, pady=5)

# -- Model Selection Frame --
model_frame = ttk.LabelFrame(root, text="Model Selection", padding=(10, 10))
model_frame.pack(padx=10, pady=10, fill="x")

ttk.Label(model_frame, text="Select Logistic Model:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
model_dropdown = ttk.Combobox(model_frame, values=list(range(1, 11)), state="readonly")
model_dropdown.grid(row=0, column=1, padx=5, pady=5)
model_dropdown.current(0)
model_dropdown.bind("<<ComboboxSelected>>", update_input_fields)

# -- Variable Inputs Frame --
variable_frame = ttk.LabelFrame(root, text="Clinical Variables", padding=(10, 10))
variable_frame.pack(padx=10, pady=10, fill="both", expand=True)

input_labels = []
input_entries = []
update_input_fields()

# -- Button Frame --
button_frame = ttk.Frame(root)
button_frame.pack(pady=20)

calculate_button = ttk.Button(button_frame, text="Calculate Mortality Probability",
                              command=on_calculate, style="Blue.TButton")
calculate_button.pack()

# ------------------- Mainloop -------------------
root.mainloop()
