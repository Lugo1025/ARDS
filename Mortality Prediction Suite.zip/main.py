import tkinter as tk
from tkinter import ttk

# --- Import and wrap calc_top as a class ---
import calc_top as top
import calc_general as general

class CalcTopApp(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.pack(fill="both", expand=True)
        self.init_gui()

    def init_gui(self):
        top_root = tk.Toplevel()
        top_root.withdraw()  # Hide original window
        self.top_widgets = []

        # Create containers
        for widget in top_root.winfo_children():
            widget.master = self
            widget.pack_forget()
            widget.pack()
            self.top_widgets.append(widget)

class CalcGeneralApp(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.pack(fill="both", expand=True)
        self.init_gui()

    def init_gui(self):
        general_root = tk.Toplevel()
        general_root.withdraw()  # Hide original window
        self.general_widgets = []

        for widget in general_root.winfo_children():
            widget.master = self
            widget.pack_forget()
            widget.pack()
            self.general_widgets.append(widget)

# --- Main Wrapper App ---
def main():
    root = tk.Tk()
    root.title("Mortality Prediction Suite")
    root.geometry("580x720")

    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True)

    tab1 = CalcTopApp(notebook)
    tab2 = CalcGeneralApp(notebook)

    notebook.add(tab1, text="Top Logistic Models")
    notebook.add(tab2, text="Tables VII–XV Models")

    root.mainloop()

if __name__ == "__main__":
    main()

