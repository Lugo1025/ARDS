import tkinter as tk
from tkinter import ttk, messagebox
import numpy as np
import csv
import os
from datetime import datetime

# ---------- Logistic Model ----------
class LogisticModel:
    def __init__(self, coefficients):
        self.coefficients = coefficients

    def predict_mortality_probability(self, input_variables):
        input_with_intercept = np.array([1] + input_variables)
        linear_combination = np.dot(self.coefficients, input_with_intercept)
        probability = 1 / (1 + np.exp(-linear_combination))
        return probability

# Model coefficients for Tables VII to XV (including intercepts as first element)
model_coefficients = {
    '1 Variable': {
        1: [-8.562, 3.142],  # VR, Glucose
        2: [-1.291,0.429],  # VR, HAS
        3: [-1.193,0.001],  # VR, COVID-19
        4: [-0.171,-0.037],  # VR, Tidal Volume (VT)
        5: [-2.581,0.066],  # VR, Age
    },    
    '2 Variables': {
        1: [-9.835,3.227, 0.006],  # VR, Glucose
        2: [-9.161, 3.28, 1.093],  # VR, HAS
        3: [-8.978, 3.119, 0.779],  # VR, COVID-19
        4: [-11.171, 3.172, 0.006],  # VR, Tidal Volume (VT)
        5: [-10, 3.159, 0.03],  # VR, Age
    },
    '3 Variables': {
        1: [-10.153, 3.113, 0.718, 0.044],  # VR, COVID-19, Pres Plat
        2: [-10.412,3.374,0.006, 1.045],  # VR, Glucose, HAS
        3: [-12.758, 3.264, 0.007, 0.007],  # VR, Glucose, VT
        4: [-11.403, 3.147,0.737, 0.006],  # VR, COVID-19, VT
        5: [-9.321, 3.181, 0.007, -0.033],  # VR, Glucose, Time
    },
    '4 Variables': {
        1: [-12.012, 3.169, 1.742, 0.009, 0.001],  # VR, Glucose, COVID-19, HAS
        2: [-11.8, 3.376, 1.374, 1.075, 0.01],  # VR, COVID-19, Time, Glucose
        3: [-12.76, 3.237, 1.494, 0.009, 0.033],  # VR, Glucose, HAS, Time, VT
        4: [-11.426, 3.129,0.01, 1.534, 0.726],  # VR, COVID-19, VT, HAS, Glucose
        5: [-13.652,3.236, 1.295,0.006, 0.01],  # VR, Glucose, Age, Time, PEEP
    },
    '5 Variables': {
        1: [-14,72, 3.195, 0.002, 2.118, 0.008, 0.047],  # VR, Glucose, COVID-19, HAS, DHL
        2: [-12.822, 3.33, 1.821,1.18, 0.002,0.009],  # VR, Glucose, DHL, COVID-19, Age, Vasopressor
        3: [-12.487, 3.091, 0.002, 1.992, 0.009, 0.806],  # VR, Glucose, COVID-19, DHL, Time, Platelets
        4: [-14.251,3.417,1.344,1.153,0.007,0.01],  # VR, Glucose, COVID-19, Platelets, PEEP, BMI
        5: [-11.211,3.324,1.353,-0.039,1.193,0.01],  # VR, COVID-19, HAS, VT, DHL
    },
    '6 Variables': {
        1: [-14.403, 3.11, 0.009, -0.044, 0.002,0.053, 2.196],  # VR, Glucose, Time, DHL, Age, COVID-19
        2: [-15.248, 3.107, 0.002, 2.39, 0.009, 0.815, 0.047],  # VR, Glucose, DHL, COVID-19, Age, Vasopressor
        3: [-12.333,3.291,1.853,-0.045,1.341,0.002,0.009],  # VR, COVID-19, Time, HAS, DHL, Glucose
        4: [-16.085,3.405,1.806,1.266,0.007,0.002,0.009],  # VR, COVID-19, VT, HAS, DHL, Glucose
        5: [-15.018,3.339,0.002,2.138,0.009,0.968,0.039],  # VR, COVID-19, HAS, DHL, VT, Glucose
    },
    '7 Variables': {
        1: [-15.749,3.377,1.83,-0.046,1.433,0.008,0.002,0.009],  # VR, COVID-19, HAS, VT, Glucose, Time
        2: [-13.79, 3.075,0.009, -0.044, 0.002, 0.052, -0.004,2.556],  # VR, Glucose, Time, DHL, Age, Platelets
        3: [-15.578, 3.093, 0.009, -0.048, 0.002, 0.058, 0.088, 2.33],  # VR, Glucose, Time, DHL, Age, COVID-19
        4: [-15.528,3.252,0.002,2.403,0.009,0.888,0.748,0.04 ],  # VR, COVID-19, HAS, PEEP, Time
        5: [-14.343, 0.21, 3.023, 0.009, -0.043, 0.002, 0.05, 2.214],  # VR, COVID-19, Time, VT, HAS
    },
    '8 Variables': {
        1: [-15.984,3.303,1.902,-0.045,0.233,1.424,0.008,0.002,0.009],  # VR, COVID-19, HAS, VT, DHL, Glucose
        2: [-13.089,3.198,1.852,-0.046,0.233,1.274,0.027,0.002,0.009],  # VR, COVID-19, Pres Plat, HAS, DHL, Glucose
        3: [-13.745,0.21,2.987,0.009,-0.044,0.002,0.05,-0.004,2.593 ],  # VR, Glucose, Time, Platelets
        4: [-12.487,3.216,0.009,0.233,-0.044,1.905,0.002,1.309,0.001],  # Glucose, Age, Creatinine
        5: [-12.991,3.277,1.807,-0.047,1.202,0.453,0.002,0.026,0.009],  # VR, Time, etc...
    },
    '9 Variables': {
        1: [-16.224, 3.311,1.914,0.505,-0.047,0.196,1.314,0.008,0.002,0.009 ],  # Example for Table XIV (needs to be filled out)
        2: [-16.459,3.289,1.85,-0.047,0.232,1.386,0.008,0.002,0.023,0.009],  # VR, COVID-19, Pres Plat, HAS, DHL, Glucose
        3: [-14.981, 0.233, 2.96, 0.009, -0.048, 0.002, 0.055, -0.003, 0.086, 2.701],  # VR, Glucose, Time, Platelets
        4: [-15.969,3.303,0.009,0.233,-0.045,1.906,0.002,-0.001,1.426,0.008],  # Glucose, Age, Creatinine
        5: [-16.514,3.37,1.794,0.621,-0.048,1.262,0.008,0.002,0.021,0.009],  # VR, Time, etc...
    },
    '10 Variables': {
        1: [-16.681,3.295,1.863,0.502,-0.048,0.196,1.276,0.008,0.002,0.023,0.009],  # VR, COVID-19, DM, Creatinine, Time
        2: [-16.692,3.271,0.009,0.243,0.068,-0.048,1.966,0.002,-0.061,1.424,0.008],  # VR, COVID-19, Pres Plat, Creatinine, Glucose, DP
        3: [-15.784, 0.212, 2.952, 0.009, -0.046, 0.002, 0.058, -0.003, 0.08, 2.729, 0.021],  # VR, BMI, Glucose
        4: [-18.107,3.245,0.266,0.128,0.01,1.669,0.008,-0.049,-0.105,0.038,1.051],  # Glucose, Age, Creatinine
        5: [-16.783,3.12,0.002,2.538,0.017,0.195,0.009,0.853,0.731,0.01,0.039 ],  # VR, Time, etc...
    },
}

# Variable names for each model (Table VII to XV)
model_variable_names = {
    '1 Variable': {
        1: ["VR"],
        2: ["Creatinine"],
        3: ["DHL"],
        4: ["Time"],
        5: ["Pres_plat"],
    },
    '2 Variables': {
        1: ["VR","Glucose"],
        2: ["VR","HAS"],
        3: ["VR","Covid"],
        4: ["VR","VT"],
        5: ["VR","Age"],
    },
    '3 Variables': {
        1: ["VR","Covid","Pres_plat"],
        2: ["VR","Glucose","HAS"],
        3: ["VR","Glucose","VT" ],
        4: ["VR","Covid","VT" ],
        5: ["VR","Glucose","Time"],
    },
    '4 Variables': {
        1: ["VR","Covid","Glucose", "DHL"],
        2: ["VR","Covid","HAS", "Glucose"],
        3: ["VR","Covid","Glucose", "Age"],
        4: ["VR","Covid","Glucose", "Vasopressor"],
        5: ["VR","Covid","VT", "Glucose"],
    },
    '5 Variables': {
        1: ["VR","DHL","Covid", "Glucose","Age"],
        2: ["VR","Covid","HAS", "DHL","Glucose "],
        3: ["VR","DHL","Covid", "Glucose","Vasopressor"],
        4: ["VR","Covid","HAS", "VT","Glucose" ],
        5: ["VR","Covid","Time", "HAS","Glucose"],
    },
    '6 Variables': {
        1: ["VR,""Glucose","Time", "DHL","Age","Covid" ],
        2: ["VR","DHL","Covid", "Glucose","Vasopressor", "Age"],
        3: ["VR","Covid","Time", "HAS","DHL","Glucose" ],
        4: ["VR","Covid","HAS", "VT","DHL","Glucose"],
        5: ["VR","DHL","Covid", "Glucose","HAS","Age"],
    },
    '7 Variables': {
        1: ["VR","Covid","Time", "HAS","VT","DHL", "Glucose"],
        2: ["VR","Glucose", "Time","DHL","Age","Platelets", "Covid"],
        3: ["VR","Glucose","Time", "DHL","Age","PEEP", "Covid"],
        4: ["VR","DHL","Covid", "Glucose","HAS", "Vasopressor","Age"],
        5: ["Creatinine","VR","Glucose", "Time","DHL","Age", "Covid"],
    },
    '8 Variables': {
        1: ["VR","Covid", "Time","Creatinine","HAS", "VT","DHL","Glucose"],
        2: ["VR","Covid","Time", "Creatinine","HAS","Pres_plat", "DHL","Glucose"],
        3: ["Creatinine","VR","Glucose", "Time","DHL","Age", "Platelets","Covid"],
        4: ["VR","Glucose","Creatinine", "Time","Covid","DHL", "HAS","DP"],
        5: ["VR","Covid", "Time","HAS","DM", "DHL","Pres_plat","Glucose"],
    },
    '9 Variables': {
        1: ["VR","Covid","DM", "Time","Creatinine","HAS", "VT","DHL","Glucose"],
        2: ["VR","Covid","Time", "Creatinine","HAS","VT", "DHL","Pres_plat","Glucose"],
        3: ["Creatinine","VR","Glucose", "Time","DHL","Age", "Platelets","PEEP","Covid"],
        4: ["VR","Glucose","Creatinine", "Time","Covid","DHL", "DP","HAS","VT"],
        5: ["VR","Covid","DM", "Time","HAS","VT", "DHL","Pres_plat","Glucose"],
    },
    '10 Variables': {
        1: ["VR","Covid","DM", "Time","Creatinine","HAS", "VT","DHL","Pres_plat", "Glucose"],
        2: ["VR","Glucose","Creatinine", "Pres_plat","Time","Covid", "DHL","DP","HAS","VT"],
        3: ["Creatinine","VR","Glucose", "Time","DHL","Age", "Platelets","PEEP","Covid", "BMI"],
        4: ["VR","Creatinine","Pres_plat", "Glucose","Covid","VT", "Time","DP","Age","HAS"],
        5: ["VR","DHL","Covid", "Pres_plat","Creatinine","Glucose", "HAS","Vasopressor","FC","Age"],        
    },
}
# ---------- Logic Functions ----------
def calculate_mortality(table, model_number, input_variables):
    coefficients = model_coefficients[table][model_number]
    model = LogisticModel(coefficients)
    return model.predict_mortality_probability(input_variables)

def save_to_csv(patient_id, patient_name, table, model_number, input_values, variable_names, probability):
    filename = "mortality_results_v2.csv"
    file_exists = os.path.isfile(filename)
    with open(filename, mode="a", newline='') as file:
        writer = csv.writer(file)
        if not file_exists:
            writer.writerow([
                "Timestamp", "Patient ID", "Patient Name", "# Variables", "Model", "Variables (Name=Value)", "Mortality Probability"
            ])
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        variables_str = "; ".join([f"{name}={val:.4f}" for name, val in zip(variable_names, input_values)])
        writer.writerow([
            timestamp, patient_id, patient_name, table, model_number, variables_str, f"{probability:.4f}"
        ])

def on_calculate():
    try:
        patient_id = patient_id_entry.get().strip()
        patient_name = patient_name_entry.get().strip()
        table = table_dropdown.get()
        model_number = int(model_dropdown.get())
        input_values = [float(entry.get()) for entry in input_entries]
        variable_names = model_variable_names[table][model_number]
        probability = calculate_mortality(table, model_number, input_values)
        save_to_csv(patient_id, patient_name, table, model_number, input_values, variable_names, probability)

        messagebox.showinfo(
            "Mortality Probability",
            f"Patient ID: {patient_id}\nName: {patient_name}\nModel: {model_number} ({table})\n\nMortality Probability: {probability:.4f}"
        )
    except Exception as e:
        messagebox.showerror("Error", str(e))

def update_input_fields(event=None):
    table = table_dropdown.get()
    try:
        model_number = int(model_dropdown.get())
    except:
        return

    for widget in variable_frame.winfo_children():
        widget.destroy()
    input_labels.clear()
    input_entries.clear()

    variable_names = model_variable_names[table][model_number]
    for i, var_name in enumerate(variable_names):
        lbl = ttk.Label(variable_frame, text=f"{var_name}:", font=('Segoe UI', 10))
        lbl.grid(row=i, column=0, padx=5, pady=5, sticky="e")
        ent = ttk.Entry(variable_frame)
        ent.grid(row=i, column=1, padx=5, pady=5)
        input_labels.append(lbl)
        input_entries.append(ent)

def update_model_options(event=None):
    table = table_dropdown.get()
    model_numbers = list(model_coefficients[table].keys())
    model_dropdown['values'] = model_numbers
    model_dropdown.current(0)
    update_input_fields()

# ---------- GUI Layout ----------
root = tk.Tk()
root.title("Mortality Probability Calculator (Tables VII to XV)")
root.geometry("550x700")
root.configure(bg="#f2f2f2")
root.resizable(False, False)

style = ttk.Style()
style.theme_use("default")
style.configure("TLabel", font=("Segoe UI", 10))
style.configure("TEntry", font=("Segoe UI", 10))
style.configure("TCombobox", padding=4)

# 🎨 Blue Button Style
style.configure("Blue.TButton",
                background="#007acc",
                foreground="white",
                font=("Segoe UI", 10, "bold"),
                padding=6)
style.map("Blue.TButton",
          background=[("active", "#005f99")],
          foreground=[("active", "white")])

# ---------- Frames ----------
patient_frame = ttk.LabelFrame(root, text="Patient Information", padding=10)
patient_frame.pack(padx=10, pady=10, fill="x")

ttk.Label(patient_frame, text="Patient ID:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
patient_id_entry = ttk.Entry(patient_frame)
patient_id_entry.grid(row=0, column=1, padx=5, pady=5)

ttk.Label(patient_frame, text="Patient Name:").grid(row=1, column=0, padx=5, pady=5, sticky="e")
patient_name_entry = ttk.Entry(patient_frame)
patient_name_entry.grid(row=1, column=1, padx=5, pady=5)

selection_frame = ttk.LabelFrame(root, text="Model Selection", padding=10)
selection_frame.pack(padx=10, pady=10, fill="x")

ttk.Label(selection_frame, text="# Variables:").grid(row=0, column=0, padx=5, pady=5, sticky="e")
table_dropdown = ttk.Combobox(selection_frame, values=list(model_coefficients.keys()), state="readonly")
table_dropdown.grid(row=0, column=1, padx=5, pady=5)
table_dropdown.current(0)
table_dropdown.bind("<<ComboboxSelected>>", update_model_options)

ttk.Label(selection_frame, text="Model #:").grid(row=1, column=0, padx=5, pady=5, sticky="e")
model_dropdown = ttk.Combobox(selection_frame, values=[], state="readonly")
model_dropdown.grid(row=1, column=1, padx=5, pady=5)
model_dropdown.bind("<<ComboboxSelected>>", update_input_fields)

variable_frame = ttk.LabelFrame(root, text="Input Clinical Variables", padding=10)
variable_frame.pack(padx=10, pady=10, fill="both", expand=True)

input_labels = []
input_entries = []

# ---------- Calculate Button ----------
button_frame = ttk.Frame(root)
button_frame.pack(pady=20)

calculate_button = ttk.Button(button_frame, text="Calculate Mortality Probability",
                              command=on_calculate, style="Blue.TButton")
calculate_button.pack()

# ---------- Initialize Dropdowns ----------
update_model_options()

# ---------- Start Application ----------
root.mainloop()

